//
//  Student+CoreDataClass.swift
//  StudentCollege
//
//  Created by SOTSYS027 on 15/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {
    static let entityName = AlertField.studentTitle
}
