//
//  Databasehelper.swift
//  CoreDatawithModelClass
//
//  Created by SOTSYS027 on 13/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import Foundation
import CoreData
import UIKit
class DatabaseHelper{
    
    // MARK: - Initialisation
    static let shareInstance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    // MARK: - Save College
    func save(object:[String:String]){
        let entityName = NSEntityDescription.insertNewObject(forEntityName: College.entityName, into: context) as! College
        entityName.name = object[Field.name]
        entityName.address = object[Field.address]
        entityName.city = object[Field.city]
        entityName.university = object[Field.uni]
        do{
            try context.save()
        }catch let error as NSError{
            print(ErrTitle.errSave + error.localizedDescription)
        }
    }
    
    // MARK: - College Edit
    func edit(in data:[String:String], indexId:Int){
        var people = getAllData()
        people[indexId].name = data[Field.name]
        people[indexId].address = data[Field.address]
        people[indexId].city = data[Field.city]
        people[indexId].university = data[Field.uni]
        do{
            try context.save()
        }catch let error as NSError{
            print(ErrTitle.errEdit + error.localizedDescription)
        }
    }
    
    // MARK: - Student Edit
    func editStudent(object:[String:String], index:Int, studData:[Student]){
        studData[index].name = object[Field.name]
        studData[index].email = object[Field.email]
        studData[index].phone = object[Field.phone]
        studData[index].birthdate = object[Field.bdate]
        do{
            try context.save()
        }catch let error as NSError{
            print(ErrTitle.errEdit + error.localizedDescription)
        }
    }
    // MARK: - Get College Filter Data
    func getCollegeFilteredData(name:String) -> [College]{
        var people:[College] = []
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: College.entityName)
        if name.count > 0{
            let namePredicate = NSPredicate(format: PreField.name,name)
            fetchRequest.predicate = namePredicate
        }
        do{
            people = try context.fetch(fetchRequest) as! [College]
            print(people)
        }catch let error as NSError{
            print(ErrTitle.errGet + error.localizedDescription)
        }
        return people
    }
    
    // MARK: - Get Student Filter Data
    func getStudentFilterdData(name:String, college:College) -> [Student]{
        var student:[Student] = []
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: Student.entityName)
        if name.count > 0{
            let predicate1 = NSPredicate(format: PreField.uName,college.name!)
            print(predicate1)
            let predicate2 = NSPredicate(format: PreField.name, name)
            print(predicate2)
            let predicateCompound = NSCompoundPredicate.init(type: .and, subpredicates: [predicate1,predicate2])
            fetchRequest.predicate = predicateCompound
        }
        do{
            student = try context.fetch(fetchRequest) as! [Student]
            print(student)
        }catch let error as NSError{
            print(ErrTitle.errGet + error.localizedDescription)
        }
        return student
    }
    
    // MARK: - getCollegeData
    func getAllData() -> [College]{
        var people:[College] = []
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: College.entityName)
        do{
            people = try context.fetch(fetchRequest) as! [College]
            print(people)
        }catch let error as NSError{
            print(ErrTitle.errGet + error.localizedDescription)
        }
        return people
    }
    // MARK: - Delete College Data
    func deleteCollege(index:Int) -> [College]{
            var people = getAllData()
            context.delete(people[index])
            people.remove(at: index)
            do{try context.save()
            }
            catch let error as NSError{
                print(ErrTitle.errDelete + error.localizedDescription)
        }
        return people
    }
    
    // MARK: - Save Student Data
    func saveStudent(object:[String:String],college:College){
        let entityName = NSEntityDescription.insertNewObject(forEntityName: Student.entityName, into: context) as! Student
        entityName.name = object[Field.name]
        entityName.email = object[Field.email]
        entityName.phone = object[Field.phone]
        entityName.birthdate = object[Field.bdate]
        entityName.universities = college
        do{
            try context.save()
        }catch let error as NSError{
            print(ErrTitle.errSave + error.localizedDescription)
        }
    }
   
    // MARK: - Delete Student Data
    func deleteStudent(index:Int, _ object: inout [Student]){
        object.remove(at: index)
        context.delete(object[index])
        do{
            try context.save()
        }
        catch let error as NSError{
            print(ErrTitle.errDelete + error.localizedDescription)
        }
    }
}


