//
//  StudentCell.swift
//  StudentCollege
//
//  Created by SOTSYS027 on 13/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class StudentCell: UITableViewCell {
    
    // MARK: - Outlets
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    var studentData:Student?{
        didSet{
            lblName.text = "\(LabelField.name): " + (self.studentData?.name)!
            lblEmail.text = "\(LabelField.email): " + (self.studentData?.email)!
            lblAge.text = "\(LabelField.age): " + self.studentData!.birthdate!.calcAge()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
