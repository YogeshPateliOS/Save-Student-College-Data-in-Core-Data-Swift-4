//
//  CollegeCell.swift
//  StudentCollege
//
//  Created by SOTSYS027 on 13/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class CollegeCell: UITableViewCell {
    
    // MARK: - Outlets
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelCity: UILabel!
    @IBOutlet weak var labelUni: UILabel!
    var cellData:College?{
        didSet{
            labelName.text = "\(LabelField.name): " + (self.cellData?.name)!
            labelCity.text = "\(LabelField.city): " + (self.cellData?.city)!
            labelUni.text = "\(LabelField.uni): "  + (self.cellData?.university)!
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
