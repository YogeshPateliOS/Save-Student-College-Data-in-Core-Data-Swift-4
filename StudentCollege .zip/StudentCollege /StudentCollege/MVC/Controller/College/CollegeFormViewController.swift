//
//  CollegeFormViewController.swift
//  StudentCollege
//
//  Created by SOTSYS027 on 13/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
class CollegeFormViewController: UIViewController{
    
    // MARK: - Outlets
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtUnivercity: UITextField!
    @IBOutlet weak var btnSave: UIButton!
    var indexRow = Int()
    var isUpdate:Bool = false
    var FormData:College?
    
    // MARK: - UIView Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        txtName.text = self.FormData?.name
        txtAddress.text = self.FormData?.address
        txtCity.text = self.FormData?.city
        txtUnivercity.text = self.FormData?.university
    }
    override func viewWillAppear(_ animated: Bool) {
        if isUpdate{
            btnSave.setTitle("Update", for: .normal)
        }else{
            btnSave.setTitle("Save", for: .normal)
        }
    }
    // MARK: - Actions
    @IBAction func btnSaveClick(_ sender: UIButton) {
        let dict:[String:String] = [Field.name:txtName.text!,Field.address:txtAddress.text!,Field.city:txtCity.text!,Field.uni:txtUnivercity.text!]
        if txtName.text == Field.emptyString{
           UIAlertController.alert(title: AlertField.collegeTitle, message: AlertField.messName, viewcontroller: self)
        }else if txtAddress.text == Field.emptyString{
            UIAlertController.alert(title: AlertField.collegeTitle, message: AlertField.messAddress, viewcontroller: self)
        }else if txtCity.text == Field.emptyString{
            UIAlertController.alert(title: AlertField.collegeTitle, message: AlertField.messCity, viewcontroller: self)
        }else if txtUnivercity.text == Field.emptyString{
            UIAlertController.alert(title: AlertField.collegeTitle, message: AlertField.messUni, viewcontroller: self)
        }else{
            if isUpdate == true{
                DatabaseHelper.shareInstance.edit(in: dict, indexId: indexRow)
                isUpdate = false
            }else{
                DatabaseHelper.shareInstance.save(object: dict)
            }
            self.navigationController?.popViewController(animated: true)
        }
    }
}

