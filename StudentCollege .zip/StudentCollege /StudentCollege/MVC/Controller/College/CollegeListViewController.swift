//
//  CollegeListViewController.swift
//  StudentCollege
//
//  Created by SOTSYS027 on 13/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class CollegeListViewController: UIViewController, UISearchBarDelegate{
    
    // MARK: - Outlets
    @IBOutlet weak var tableView: UITableView!
    var arrData:[College] = []
    var college:College?
    var searchActive:Bool = false
    let height:CGFloat = 117
    @IBOutlet weak var searchController: UISearchBar!
    
    // MARK: - UIView Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView()
    }
    override func viewWillAppear(_ animated: Bool) {
        searchController.text = nil
        arrData = DatabaseHelper.shareInstance.getAllData()
        self.tableView.reloadData()
    }
    
    // MARK: - Actions
    @IBAction func btnSaveClick(_ sender: UIBarButtonItem) {
        let formVC = self.storyboard?.instantiateViewController(withIdentifier:Identifier.collegeForm) as? CollegeFormViewController
        self.navigationController?.pushViewController(formVC!, animated: true)
//        var vc:CollegeFormViewController!
//        vc = UIStoryboard.storyboardNavigation(storyboard: Identifier.collegeStory, identifier: Identifier.collegeForm) as! CollegeFormViewController
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //SeacrhBar Method..
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchActive = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchActive = false
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText == Field.emptyString{
          searchActive = false
        }else{
          searchActive = true
        }
        arrData = DatabaseHelper.shareInstance.getCollegeFilteredData(name: searchText)
        self.tableView.reloadData()
    }
}

// MARK: - Datasource TableView Methods
extension CollegeListViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchActive{
            return arrData.count
        }else{
            return arrData.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Identifier.collegeCell, for: indexPath) as? CollegeCell
        if searchActive{
            cell?.cellData = arrData[indexPath.row]
        }else{
            cell?.cellData = arrData[indexPath.row]
        }
        return cell!
    }
}

// MARK: - Delegate TableView Methods
extension CollegeListViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: Identifier.collegeDetail) as? CollegeDetailViewController
        if searchActive{
            detailVC?.detailData = arrData[indexPath.row]
        }else{
            detailVC?.detailData = arrData[indexPath.row]
            let indexTable = indexPath.row
            detailVC?.index = indexTable
        }
        self.navigationController?.pushViewController(detailVC!, animated: true)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return height
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
          arrData = DatabaseHelper.shareInstance.deleteCollege(index: indexPath.row)
          self.tableView.deleteRows(at: [indexPath], with: .automatic)
       }
    }
}


