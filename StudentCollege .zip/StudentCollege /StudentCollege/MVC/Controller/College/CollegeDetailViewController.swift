//
//  CollegeDetailViewController.swift
//  StudentCollege
//
//  Created by SOTSYS027 on 13/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
import CoreData
class CollegeDetailViewController: UITableViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelAddress: UILabel!
    @IBOutlet weak var labelCity: UILabel!
    @IBOutlet weak var labelUni: UILabel!
    @IBOutlet weak var labelStudent: UILabel!
    var detailData:College!
    var isEdit:Bool = true
    var index = Int()
    
    // MARK: - UIView Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView()
    }
    override func viewWillAppear(_ animated: Bool) {
        labelName.text = LabelField.name + (self.detailData.name)!
        labelAddress.text = LabelField.address + (self.detailData.address)!
        labelCity.text = LabelField.city + (self.detailData.city)!
        labelUni.text = LabelField.uni + (self.detailData.university)!
        labelStudent.text = LabelField.studentCount + "\(self.detailData.students!.count)"
    }
    
    // MARK: - Actions
    @IBAction func btnEditClick(_ sender: UIBarButtonItem) {
        let formVC = self.storyboard?.instantiateViewController(withIdentifier: Identifier.collegeForm) as? CollegeFormViewController
        formVC?.FormData  = detailData
        formVC?.isUpdate = isEdit
        formVC?.indexRow = index
        
        self.navigationController?.pushViewController(formVC!, animated: true)
    }
    
    // MARK: - TableView Methods
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 2{
            let storyboard = UIStoryboard.init(name: Identifier.studentStory, bundle: nil)
            let listVC = storyboard.instantiateViewController(withIdentifier: Identifier.studentList) as? StudentListViewController
            listVC?.college = detailData
            self.navigationController?.pushViewController(listVC!, animated: true)
        }
    }
}
