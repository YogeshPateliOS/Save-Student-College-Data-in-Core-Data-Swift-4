//
//  StudentDetailViewController.swift
//  StudentCollege
//
//  Created by SOTSYS027 on 13/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class StudentDetailViewController: UITableViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    @IBOutlet weak var lblbdate: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    @IBOutlet weak var lblClgName: UILabel!
    var indexDetail = Int()
    var studentData:Student!
    var dataDetail:[Student] = []
    
    // MARK: - UIView Lifecycle
    override func viewDidLoad() {
        self.tableView.tableFooterView = UIView()
        super.viewDidLoad()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Edit", style: .plain, target: self, action: #selector(btnEditClick))
    }
    override func viewWillAppear(_ animated: Bool) {
        lblName.text = LabelField.name + (self.studentData?.name)!
        lblEmail.text = LabelField.email + (self.studentData?.email)!
        lblPhone.text = LabelField.phone + (self.studentData?.phone)!
        lblbdate.text = LabelField.bdate + (self.studentData?.birthdate)!
        lblAge.text = LabelField.age + "\(self.studentData.birthdate!.calcAge())"
        lblClgName.text = LabelField.collegeName + self.studentData.universities!.name!
    }
    
    // MARK: - Methods
    @objc func btnEditClick(_ sender: UIBarButtonItem){
        let studForm = self.storyboard?.instantiateViewController(withIdentifier: Identifier.studentForm) as! StudentFormViewController
        studForm.studentData = studentData
        studForm.index = indexDetail
        studForm.data = dataDetail
        let isUpdate:Bool = true
        studForm.isEdit = isUpdate
        self.navigationController?.pushViewController(studForm, animated: true)
    }
    
}
