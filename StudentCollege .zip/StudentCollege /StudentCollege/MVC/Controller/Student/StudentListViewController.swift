//
//  StudentListViewController.swift
//  StudentCollege
//
//  Created by SOTSYS027 on 13/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
import CoreData
class StudentListViewController: UIViewController, UISearchBarDelegate {
    
    // MARK: - Outlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchController: UISearchBar!
    var arrData:[Student] = []
    var isSearch:Bool = false
    var college: College?
    let height:CGFloat = 80
    
    // MARK: - UIView Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        if college?.students != nil{
            arrData = college?.students?.allObjects as! [Student]
            self.tableView.reloadData()
        }
        self.tableView.tableFooterView = UIView()
    }
    override func viewWillAppear(_ animated: Bool) {
        searchController.text = nil
        if college?.students != nil && searchController.text == ""{
            arrData = college?.students?.allObjects as! [Student]
            self.tableView.reloadData()
        }
    }
    
    // MARK: - SearchBar Method
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSearch = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        isSearch = false
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        isSearch = false
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSearch = false
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText == Field.emptyString{
            isSearch = false
        }else{
            isSearch = true
        }
        if searchText == ""{
            arrData = college?.students?.allObjects as! [Student]
            self.tableView.reloadData()
        }else{
            arrData = DatabaseHelper.shareInstance.getStudentFilterdData(name: searchText, college: college!)
            self.tableView.reloadData()
        }
        print(arrData)
    }
    // MARK: - Actions
    @IBAction func btnSaveClick(_ sender: UIBarButtonItem) {
        let formVC = self.storyboard?.instantiateViewController(withIdentifier: Identifier.studentForm) as? StudentFormViewController
        formVC?.college = college
        self.navigationController?.pushViewController(formVC!, animated: true)
    }
}

// MARK: - TableView Delegate & Datasource Methods
extension StudentListViewController: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearch{
            return arrData.count
        }else{
            return arrData.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Identifier.studentCell, for: indexPath) as? StudentCell
        if isSearch{
            cell?.studentData = arrData[indexPath.row]
        }else{
            cell?.studentData = arrData[indexPath.row]
        }
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return height
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: Identifier.studentDetail) as? StudentDetailViewController
        let indexRow = indexPath.row
        detailVC?.indexDetail = indexRow
        detailVC?.dataDetail = arrData
        if isSearch{
            detailVC?.studentData = arrData[indexPath.row]
        }else{
            detailVC?.studentData = arrData[indexPath.row]
        }
        self.navigationController?.pushViewController(detailVC!, animated: true)
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            DatabaseHelper.shareInstance.deleteStudent(index: indexPath.row, &arrData)
            self.tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
}
