
import UIKit

class StudentFormViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtBirthdate: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var btnSave: UIButton!
    var college:College?
    var studentData:Student?
    var data:[Student] = []
    var isEdit:Bool = false
    var index = Int()
    
    // MARK: - UIView Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        txtName.text = studentData?.name
        txtPhone.text = studentData?.phone
        txtEmail.text = studentData?.email
        txtBirthdate.text = studentData?.birthdate
    }
    override func viewWillAppear(_ animated: Bool) {
        if isEdit{
            btnSave.setTitle("Update", for: .normal)
        }else{
            btnSave.setTitle("Save", for: .normal)
        }
    }
    
    // MARK: - Actions
    @IBAction func btnSaveClick(_ sender: UIButton) {
        let dict:[String:String] = [Field.name:txtName.text!,Field.email:txtEmail.text!,Field.phone:txtPhone.text!,Field.bdate:txtBirthdate.text!]
        if txtName.text == Field.emptyString{
            UIAlertController.alert(title: AlertField.studentTitle, message: AlertField.messName, viewcontroller: self)
        }else if txtEmail.text == Field.emptyString{
            UIAlertController.alert(title: AlertField.studentTitle, message: AlertField.messEmail, viewcontroller: self)
        }else if txtPhone.text == Field.emptyString{
            UIAlertController.alert(title: AlertField.studentTitle, message: AlertField.messPhone, viewcontroller: self)
        }else if txtBirthdate.text == Field.emptyString{
            UIAlertController.alert(title: AlertField.studentTitle, message: AlertField.messBdate, viewcontroller: self)
        }else{
            if isEdit == true{
                DatabaseHelper.shareInstance.editStudent(object: dict, index: index, studData: data)
                isEdit = false
            }else{
                DatabaseHelper.shareInstance.saveStudent(object: dict, college: college!)
            }
            self.navigationController?.popViewController(animated: true)
        }
    }
}
