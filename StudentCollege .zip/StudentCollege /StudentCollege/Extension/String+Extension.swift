import Foundation

// MARK: - Birthdate to Age Extension
extension String{
    func calcAge() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/dd/yyyy"
        let yourDate = formatter.date(from: self)
        let calendar: NSCalendar! = NSCalendar(calendarIdentifier: .indian)
        let now = Date()
        return "\(calendar.components(.year, from: yourDate!, to: now, options: []).year!)"
    }
}
