//
//  Storyboard+Extension.swift
//  StudentCollege
//
//  Created by SOTSYS027 on 19/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import Foundation
import UIKit
extension UIStoryboard{
    static func storyboardNavigation(storyboard:String, identifier:String) -> UIViewController{
        let sb = UIStoryboard(name: storyboard, bundle: Bundle.main)
        return sb.instantiateViewController(withIdentifier: identifier)
    }
}
